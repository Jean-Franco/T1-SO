Integrantes: Jean Franco Z�rate, 201773524-4
	     Ignacio Aedo Villagra, 201773556-2

**************** entrega 1 ***********************
Logramos programar todo el primer punto, por lo que nuestro programa actualmente navega, crea y mueve los archivos de carpeta en carpeta.
Crea las 108 cartas en la carpeta mazo y reparte 7 cartas aleatorias a cada jugador.
C�mo ejecutar el c�digo:
Abrir t1.c y editar las variables mazo, jugador1, jugador2,jugador3 y jugador4 definidas con #define por las direcciones 
exactas donde se ejecutar� el programa manteniendo la �ltima direcci�n (/mazo, /jugador1,etc). EJEMPLO EN LINUX (probado en LDS):

#define mazo "/home/ignacio.aedo/Escritorio/t1SO/mazo" ---> mantener /mazo
OTRO EJEMPLO (en el bash de ubuntu en Windows):
#define mazo "/mnt/d/2019-2/so/t1/mazo"

**************** entrega 2**************************
Logramos programar todo el segundo punto y arreglar el problema presentado de tener que escribir la direcci�n del PC que se est� ocupando, 
por lo que logramos integrar la entrega1 corregida con la entrega 2. *ignorar el git y solo tomar en cuenta los tar.gz ya que no sabemos ocupar git*
Instrucciones para correr:
ejecutar el makefile con el comando:
make run


